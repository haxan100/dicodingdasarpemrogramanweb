function myFunction() {
    // console.log("text");
    var x = document.getElementById("mainstwo");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
}
function personal() {
    // console.log("text");
    var x = document.getElementById("exp");
    var y = document.getElementById("tambahan_edu");
    // var x = document.getElementById("personal");
    var z = document.getElementById("me");
    if (x.style.display === "none") {
        x.style.display = "block";
        y.style.display = "block";
        z.style.display = "block";
    } else {
        x.style.display = "none";
        y.style.display = "none";
        z.style.display = "none";
    }
}

function All() {
    // console.log("text");
    var x = document.getElementById("exp");
    var y = document.getElementById("tambahan_edu");
    var o = document.getElementById("personal");
    var z = document.getElementById("me");
    if (x.style.display === "none") {
        x.style.display = "block";
        y.style.display = "block";
        z.style.display = "block";
        o.style.display = "block";
    } else {
        x.style.display = "none";
        y.style.display = "none";
        z.style.display = "none";
        o.style.display = "none";
    }
}
function me() {
    // console.log("text");
    var x = document.getElementById("exp");
    var y = document.getElementById("tambahan_edu");
    var o = document.getElementById("personal");
    // var z = document.getElementById("me");
    if (x.style.display === "none") {
        x.style.display = "block";
        y.style.display = "block";
        // z.style.display = "block";
        o.style.display = "block";
    } else {
        x.style.display = "none";
        y.style.display = "none";
        // z.style.display = "none";
        o.style.display = "none";
    }
}
function Experience() {
    // console.log("text");
    // var x = document.getElementById("exp");
    var y = document.getElementById("tambahan_edu");
    var o = document.getElementById("personal");
    var z = document.getElementById("me");
    if (y.style.display === "none") {
        // x.style.display = "block";
        y.style.display = "block";
        z.style.display = "block";
        o.style.display = "block";
    } else {
        // x.style.display = "none";
        y.style.display = "none";
        z.style.display = "none";
        o.style.display = "none";
    }
}